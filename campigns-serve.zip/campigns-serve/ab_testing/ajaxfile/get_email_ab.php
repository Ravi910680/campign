


<?php
//get the html returned from the following url
$html = file_get_contents('https://app.mailgenius.com/spam-test/ad3ad1'); 
//init DOMDocument\



function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}


function strip_tags_content($string) { 
    // ----- remove HTML TAGs ----- 
    $string = preg_replace ('/<[^>]*>/', ' ', $string); 
    // ----- remove control characters ----- 
    $string = str_replace("\r", '', $string);
    $string = str_replace("\n", ' ', $string);
    $string = str_replace("\t", ' ', $string);
    // ----- remove multiple spaces ----- 
    $string = trim(preg_replace('/ {2,}/', ' ', $string));
    return $string; 

}

   $res_arr=array();


$array_of_id=array('1','6','7','9','10','11');

if(!empty($html)){ 
	

$start='data-inbound_email_audit_json="';
$end='"';


$str_enc=get_string_between($html, $start, $end);


$jsn_data=json_decode(str_replace("&quot;",'"',$str_enc));




$res_arr['score']=$jsn_data->mailTesterProps->score;


$all_aspc_cnt=0;

foreach ($array_of_id as $key => $value) {
	

$asp_data=$jsn_data->mailTesterProps->aspects[$value];


$nam_fld=$asp_data->id;

$res_arr['aspect_of'][$all_aspc_cnt]['name']=$nam_fld;
$res_arr['aspect_of'][$all_aspc_cnt]['passed_val']=$asp_data->passing;
$res_arr['aspect_of'][$all_aspc_cnt]['status']=$asp_data->status;
$res_arr['aspect_of'][$all_aspc_cnt]['message']=$asp_data->message;

$all_fact=$asp_data->factors;

$fact_id=0;

foreach ($all_fact as $key_2 => $value_2) {

$fact_data=$value_2;



	$res_arr['aspect_of'][$all_aspc_cnt]['factor']['data'][$fact_id]['id']=$fact_data->id;
	$res_arr['aspect_of'][$all_aspc_cnt]['factor']['data'][$fact_id]['title']=$fact_data->title;
	$res_arr['aspect_of'][$all_aspc_cnt]['factor']['data'][$fact_id]['passed_val']=$fact_data->passing;
	$res_arr['aspect_of'][$all_aspc_cnt]['factor']['data'][$fact_id]['solution']=$fact_data->solution;
	$res_arr['aspect_of'][$all_aspc_cnt]['factor']['data'][$fact_id]['desc']=$fact_data->passing_description;


$fact_id+=1;



}


$all_aspc_cnt+=1;

}






}

$str_data=json_encode($res_arr);


print_r(strip_tags_content($str_data));

?>
