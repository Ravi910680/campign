<?php

require("../../confige/contact_confige.php");

require("../../confige/camp_confige.php");

require("../../confige/camp_analysis.php");





$camp_id=$_POST['camp_id'];

$date = $_POST['time_data']; 





$lst_id=json_decode($_POST['lst_dt']);


$date = strtotime($date); 
$sel_time_for_camp= date('Y-m-d H:i:s', $date);


$camp_con_id=1;

$isrt_camp_name="update camp_name_tbl set camp_shed_time='$sel_time_for_camp',flg_send='1'  where camp_contact_id='$camp_id'";








if ($camp_name_conn->query($isrt_camp_name) === TRUE) {
 


foreach ($lst_id as $key => $value) {


$ana_tbl_name=$camp_id."#".$value;

$tblsql = "CREATE TABLE `".$ana_tbl_name."`(
     
     id varchar(10) NOT NULL,
     act varchar(3) NOT NULL,
     cnt varchar(4),
     act_date datetime,
     reg varchar(12)
        
        )";





if($camp_ana_conn->query($tblsql)==TRUE){




	$crt_new_col_in_lst="Alter table `$value` add `$camp_id` int(2)";

	$res_add_col=$conn3->query($crt_new_col_in_lst);





}

}


 echo 1;

} else {
  echo $camp_name_conn->error;
}


?>