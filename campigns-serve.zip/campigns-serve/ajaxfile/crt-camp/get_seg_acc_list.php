<?php


require("../../confige/segment_confige.php");




function list_name_query($data_of_list){

$str_ret="";

foreach ($data_of_list as $key => $value) {
	


$str_ret="list_name='".$value."' or";

}

$str_ret=substr($str_ret, 0, -2);


return $str_ret;
}

$arr_of_dt=array();

$list_arr=json_decode($_POST['list_name']);


if(count($list_arr)>0){

$str_cond=list_name_query($list_arr);



$seg_sel_query="select * from segment_data where ".$str_cond;



$result =$seg_conn->query($seg_sel_query);



while($row = $result->fetch_assoc()) {





    $loc_arr=array();


$file_name_dec=explode("^", $row['id'])[1];

$loc_arr['label']=$file_name_dec;
$loc_arr['value']=$row['id'];

 
array_push($arr_of_dt, $loc_arr);


  }

  echo json_encode($arr_of_dt);
}

?>