<?php





$tz = 'America/Los_Angeles';
$tz_obj = new DateTimeZone($tz);
$today = new DateTime("now", $tz_obj);
$today_formatted = $today->format('Y-m-d H:i:s');


$late_time=strtotime($today_formatted);



$input = $_POST['ip_for_time_sel_camp']; 


$date = strtotime($input); 
$sel_time_for_camp= date('Y-m-d H:i:s', $date);


$sel_time_obj=strtotime($sel_time_for_camp);


if($sel_time_obj>$late_time){

	echo 1;
}else{

	echo 0;
}

?>