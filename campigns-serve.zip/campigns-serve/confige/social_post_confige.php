<?php
$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$dbname = "social_post";

$social_post_conn = mysqli_connect($servername, $username, $password,$dbname);


?>
